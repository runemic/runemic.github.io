# Runemic OCR, local MCP server

Reads document pages on your computer with [Runemic](https://runemic.com): page images (PNG, JPEG, WebP, GIF; HEIC,
TIFF and large scans are converted), PDFs and whole folders. Text comes back in reading order as Markdown or plain
text, in any script.

Needs Node 18+ and a Runemic API key from https://console.runemic.com. For PDFs, install Poppler (`pdftoppm`).

```json
{
  "mcpServers": {
    "runemic": {
      "command": "npx",
      "args": ["-y", "https://runemic.com/mcp/runemic-mcp.tgz"],
      "env": { "RUNEMIC_API_KEY": "rk_live_…" }
    }
  }
}
```

Tools: `read_file` (an image or PDF), `read_folder` (all pages in a folder, in order), `list_models`, `get_account`.
Docs: https://runemic.com/docs#mcp-local
